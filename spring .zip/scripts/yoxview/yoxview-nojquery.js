﻿jQuery(document).ready(function($){
    // Uncomment the following line if you use an additional Javascript library (likr Prototype, for example) in the same page as YoxView:
    // jQuery.noConflict();
    $(".yoxview").yoxview();
});