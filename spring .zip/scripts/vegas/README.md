# Vegas Background jQuery Plugin

Vegas is a jQuery plugin to add beautiful fullscreen backgrounds to your webpages. You can even create amazing Slideshows.

    $(function() {
	    $.vegas('/img/background.jpg')('overlay');
	}

### Official website
http://vegas.jaysalvat.com/

### Real life demo
http://vegas.jaysalvat.com/demo/

### Documentation
http://vegas.jaysalvat.com/documentation/